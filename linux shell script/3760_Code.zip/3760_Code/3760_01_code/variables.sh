#!/bin/bash
#Filename : variables.sh
fruit=apple
count=5
echo "We have $count $fruit(s)"
